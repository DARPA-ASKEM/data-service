cypher-shell -u neo4j -p password -f /populate-cache.cypher --non-interactive
